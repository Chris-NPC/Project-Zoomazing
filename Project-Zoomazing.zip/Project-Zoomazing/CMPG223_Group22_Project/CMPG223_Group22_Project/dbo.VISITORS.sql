﻿CREATE TABLE [dbo].[VISITORS] (
    [Visitors_ID]    INT           NOT NULL IDENTITY,
    [Visitors_LName] NVARCHAR (25) NULL,
    [Visitors_Name]  NVARCHAR (25) NULL,
    [Date_Of_Birth]  DATE          NULL,
    [ContactNumber]  NVARCHAR (13) NULL,
    PRIMARY KEY CLUSTERED ([Visitors_ID] ASC)
);

