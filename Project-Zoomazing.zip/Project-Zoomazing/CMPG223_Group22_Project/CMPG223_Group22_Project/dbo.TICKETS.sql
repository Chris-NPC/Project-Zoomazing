﻿CREATE TABLE [dbo].[TICKETS] (
    [Ticket_ID]     INT             NOT NULL IDENTITY,
    [Description]   NVARCHAR (25)   NULL,
    [Price]         INT NULL,
    [isTicketValid] BIT             NULL,
    PRIMARY KEY CLUSTERED ([Ticket_ID] ASC)
);

